from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from sklearn.feature_extraction.text import TfidfVectorizer
from datetime import datetime
import os
import joblib

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Simulating a database for users
users = {}
# Simulating a database for user email history
user_histories = {}

# Load your pre-trained spam/ham classifier (assuming you saved it using joblib)
model_path = 'naive_bayes_spam_model.pkl'
vectorizer_path = 'count_vectorizer.pkl'
spam_model = joblib.load(model_path)
vectorizer = joblib.load(vectorizer_path)

class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

@login_manager.user_loader
def load_user(user_id):
    return users.get(user_id)

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            flash('Username already exists!')
            return redirect(url_for('signup'))
        user = User(id=username, username=username, password=password)
        users[username] = user
        user_histories[username] = []  # Initialize user history
        flash('Signup successful! You can now log in.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.get(username)
        if user and user.password == password:
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials!')
    return render_template('login.html')

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    if request.method == 'POST':
        recipient = request.form['recipient']
        subject = request.form['subject']
        body = request.form['body']
        
        # Combine subject and body for prediction
        email_content = subject + ' ' + body
        prediction = predict_spam(email_content)
        
        # Store email check history
        history_entry = {
            'recipient': recipient,
            'subject': subject,
            'body_preview': body[:50] + "...",  # Preview of the body
            'prediction': prediction,
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        user_histories[current_user.username].append(history_entry)  # Append to user history
        
        return render_template('dashboard.html', prediction=prediction)
    return render_template('dashboard.html', prediction=None)

def predict_spam(email_content):
    # Vectorize the email content
    email_vector = vectorizer.transform([email_content])
    prediction = spam_model.predict(email_vector)[0]
    return 'Spam' if prediction == 1 else 'Ham'

@app.route('/history')
@login_required
def history():
    user_history = user_histories.get(current_user.username, [])
    return render_template('history.html', history=user_history)

@app.route('/blog')
@login_required
def blog():
    return render_template('blog.html')

@app.route('/about')
@login_required
def about():
    return render_template('about.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
